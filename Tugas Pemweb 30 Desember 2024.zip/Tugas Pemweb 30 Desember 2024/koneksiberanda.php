<?php
$koneksiberanda = mysqli_connect('localhost', 'root', "", 'money-management');
?>