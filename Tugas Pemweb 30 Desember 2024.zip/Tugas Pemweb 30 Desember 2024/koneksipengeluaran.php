<?php

$koneksipengeluaran = mysqli_connect('localhost', 'root', "", 'money-management');

?>